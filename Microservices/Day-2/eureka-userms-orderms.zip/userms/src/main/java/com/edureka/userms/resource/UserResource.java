package com.edureka.userms.resource;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.userms.model.User;
import com.edureka.userms.service.UserService;

@RestController
public class UserResource {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserResource.class);
	
	private final UserService userService;

	public UserResource(UserService userService) {
		this.userService = userService;
	}
	
	@GetMapping("/users")
	public ResponseEntity getAllUsers() {
		LOGGER.info("getting all users from service");
		return ResponseEntity.ok(userService.getAllUsers());
	}
	
	@GetMapping("/users/{userId}")
	public ResponseEntity getSingleUser(@PathVariable Long userId) {
		LOGGER.info("getting all users from service");
		Optional<User> singleUser = userService.getSingleUser(userId);
		if (!singleUser.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(singleUser);
	}
	
	@GetMapping("/ordersFromUserms")
	public ResponseEntity getAllOrders() {
		return ResponseEntity.ok(userService.getAllOrders());
	}
	
	

}
