insert into user (name) values ('Ashutosh');
insert into user (name) values ('Evangelos');
insert into user (name) values ('Girija');
insert into user (name) values ('Parinita');