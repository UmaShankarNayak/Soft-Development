insert into order_data (order_name, user_id, nick_name) values ('iPhone-X', 1, 'Apple-Phone-X');
insert into order_data (order_name, user_id, nick_name) values ('iPhone-Normal', 1, 'Apple-Phone');
insert into order_data (order_name, user_id, nick_name) values ('Nexus-7', 2, 'Google-7');
insert into order_data (order_name, user_id, nick_name) values ('Nexus-6', 2, 'Google-6');
insert into order_data (order_name, user_id, nick_name) values ('Blackberry', 2, 'BB');
insert into order_data (order_name, user_id, nick_name) values ('BlueBerry', 1, 'BB');
insert into order_data (order_name, user_id, nick_name) values ('BrownBerry', 1, 'BB');