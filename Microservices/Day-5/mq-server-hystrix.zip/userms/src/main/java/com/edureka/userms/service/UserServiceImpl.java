package com.edureka.userms.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.edureka.userms.model.User;
import com.edureka.userms.repository.UserRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class UserServiceImpl implements UserService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	
	private final UserRepository userRepository;
	private final RestTemplate restTemplate;
	
	public UserServiceImpl(UserRepository userRepository, RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
		this.userRepository = userRepository;
	}

	@Override
	public List<User> getAllUsers() {
		LOGGER.info("getting all users from repository");
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getSingleUser(Long userId) {
		LOGGER.info("getting single user from repository");
		return userRepository.findById(userId);
	}

	@Override
	public void createUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteUser(Long userId) {
		// TODO Auto-generated method stub

	}

	@Override
	public User findById(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User findByName(String userName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	@HystrixCommand(fallbackMethod = "getResponseFromFallback")
	public Object getAllOrders() {
		return restTemplate.getForObject("http://orderms/orders", Object.class);
	}
	
	private Object getResponseFromFallback() {
		User user1 = new User();
		user1.setId(1L);
		user1.setName("A");
		User user2 = new User();
		user2.setId(2L);
		user2.setName("B");
		
		return Arrays.asList(user1, user2);
	}
	
	

}
