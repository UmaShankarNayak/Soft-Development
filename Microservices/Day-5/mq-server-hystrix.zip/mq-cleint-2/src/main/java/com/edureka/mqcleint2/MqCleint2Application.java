package com.edureka.mqcleint2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.JmsListener;

@SpringBootApplication
public class MqCleint2Application {
	
	@JmsListener(destination = "queue_2")
	public void listen(String message) {
		System.out.println("client-2 received: " + message);
	}

	public static void main(String[] args) {
		SpringApplication.run(MqCleint2Application.class, args);
	}

}
