package com.edureka.mqcleint1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.JmsListener;

@SpringBootApplication
public class MqCleint1Application {
	
	@JmsListener(destination = "queue_1")
	public void listen(String message) {
		System.out.println("client-1 received: " + message);
	}

	public static void main(String[] args) {
		SpringApplication.run(MqCleint1Application.class, args);
	}

}
